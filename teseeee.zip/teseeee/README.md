项目热启动
```
npm run dev
```

参考在线教程
Express 介绍
https://www.cnblogs.com/lpl666/p/12872991.html

express的基本项目搭建实现注册登录
1，http://escook.cn:8088/#/mds/1.init
2，https://brucecai55520.gitee.io/bruceblog/notes/nodejs/mysql.html#session-%E8%AE%A4%E8%AF%81%E6%9C%BA%E5%88%B6

B站对应教程
https://www.bilibili.com/video/BV1a34y167AZ/?p=59&vd_source=69c63cb4db904f6507a11a984a9a4c9a

Mac环境下的MySQl基础操作
https://blog.csdn.net/u010184528/article/details/106176226

 3、配置MySQL

 https://blog.csdn.net/guorenhao/article/details/124508441

我们先来测试一下，在终端输入mysql，会提示命令没有发现

hello@wodeMacBook-Pro ~ % mysql
zsh: command not found: mysql

这说明我们还没有配置环境，在终端通过 vim 来编辑 .zshrc 配置文件

hello@wodeMacBook-Pro ~ % sudo vim ~/.zshrc

 点击 i 键，进入编辑模式，在配置文件中添加如下路径：

export PATH=$PATH:/usr/local/mysql/bin

然后按 esc 退出编辑模式，输入 :wq 保存退出

接着在终端执行 source ~/.zshrc 使配置生效

hello@wodeMacBook-Pro ~ % source ~/.zshrc

此时在终端查看 mysql 版本可以看到已经可以查到我们安装的版本了，说明环境已经配好

hello@wodeMacBook-Pro ~ % mysql --version

mysql  Ver 8.0.29 for macos12 on x86_64 (MySQL Community Server - GPL)

 现在就可以在终端输入 mysql -uroot -p 然后输入密码，进入MySQL使用了


 简单说一下

-u：mysql用户名，这里直接将用户名 root 挨着写在后边

-p：mysql密码，这里没有写会提示让输入，也可以直接挨着p写在后边

至此，MySQL在Mac上安装及配置全部完成，接下来就可以开始MySQL使用操作了。
————————————————
