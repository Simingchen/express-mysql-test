import mysql from 'mysql'

// 创建数据库连接对象
export default mysql.createPool({
  host: '127.0.0.1',
  user: 'root',
  password: 'Siming123',
  database: 'my_db_01'
})
// 登录数据库
// mysql -u root -p
// 创建数据库：mysql> create DATABASE my_db_01;
// create database my_db_01 character utf8
// id 自增加上1
// create table ev_users(
//   id int primary key auto_increment,
//   username varchar(200),
//   password varchar(200),
//   nickname varchar(200),
//   email varchar(200),
//   user_pic varchar(200)
// );
