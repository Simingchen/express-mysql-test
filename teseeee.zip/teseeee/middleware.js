import joi from 'joi'
// 错误中间件
export function joiValidationError(err, req, res, next) {
  // 数据验证失败
  if (err instanceof joi.ValidationError) return res.cc(err)
  // 未知错误
  res.cc(err)
}

export function errorMiddle(req, res, next) {
  // code = 200 为成功； code = 500 为失败； 默认将 code 的值设置为 200，方便处理失败的情况
  res.cc = function(err, code = 500) {
    res.send({
      // 状态
      code,
      // 状态描述，判断 err 是 错误对象 还是 字符串
      message: err instanceof Error ? err.message : err
    })
  }
  next()
}

export function UnauthorizedError(err, req, res, next) {
  // 捕获身份认证失败的错误
  if (err.name === 'UnauthorizedError') return res.cc('身份认证失败！')
  // 未知错误...
  next()
}
