export function routerSuccess(res) {
  res.status(200).json({
    code: 200,
    data: [],
    msg: '操作成功'
  })
}
