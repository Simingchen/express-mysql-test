export default {
  jwtSecretKey: 'Bruce',
}
