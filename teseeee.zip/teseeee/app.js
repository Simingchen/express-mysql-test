import express from 'express'
const app = express()

import cookieParser from 'cookie-parser'
app.use(cookieParser())

// 需要配置一个解析 body 数据的中间件
import bodyparser from 'body-parser'
app.use(bodyparser.json())

// 需要配置一个解析表单数据的中间件
app.use(express.urlencoded({ extended: true }))

// 允许客户端请求跨域
import cors from 'cors'
app.use(cors())

// 错误中间件
import { joiValidationError, errorMiddle, UnauthorizedError } from './middleware.js'
app.use(joiValidationError)
// 响应数据的中间件 定义错误 res.cc
app.use(errorMiddle)

app.use(UnauthorizedError)

// 注册路由之前，配置解析 Token 的中间件
import config from './config.js'
import expressJWT from 'express-jwt'
// 使用 .unless({ path: [/^\/api\//] }) 指定哪些接口不需要进行 Token 的身份认证
app.use(expressJWT({ secret: config.jwtSecretKey }).unless({ path: [/^\/api\/common/] }))

// 静态目录
app.use('/express', express.static('static'))

// 注册用户模块
import userRouter from './router/user.js'
import userInfoRouter from './router/userInfo.js'
app.use('/api/common', userRouter)
app.use('/api/user', userInfoRouter)

// 调用 app.listen 方法，指定端口号并启动web服务器
const port = parseFloat(process.env['APP_PROT'] || '3007')
app.listen(port, function() {
  console.log(`api server running at http://127.0.0.1:${port}`)
})
